name = input("Enter your Full Name: ")
print(f"Hello, {name}!")
